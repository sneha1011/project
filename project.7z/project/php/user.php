<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
     
    </div>
    <ul class="nav navbar-nav">
	<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">MENU <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="breakfast.html">Breakfast</a></li>
          <li><a href="bevrages.html">Bavrages</a></li>
          <li><a href="lunch.html">Lunch</a></li>
          <li><a href="snacks.html">Snacks</a></li>
        </ul>
	
      <li><a href="#">ACCOUNT</a></li>
      <li><a href="#">REVIEW</a></li>
	   <li><a href="about.html">ABOUT</a></li>
	   <li><a href="#">LOGOUT</a></li>
    </ul>
	
  </div>
</nav>
<img src="food4.jpg" width=100%; height=100%; >
