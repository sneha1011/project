<html>
< head >
<titlie>My online shop</title>
<link ref="stylesheet" href="styles/style.css media="all"/>
</head>
<body>
<div class="main_wrapper">
<div class="header_wrapper">
<img id="logo" src=" path">
<img id="banner" src=" path">
</div>
<div class="menubar"><ul id="menu"><li>
	<a href="#">HOME</a></li>
	<li>
	<a href="#">ALL PRODUCT</a></li>
	<li>
	<a href="#">CART</a></li>
	<li>
	<a href="#">ACCOUNT</a></li>
	<li>
	<a href="#">CONTACT</a></li>
	</ul>
	<div id="form">
		<form method="get" action ="results.php" enctype ="multipart/form-data">
			<input type ="text" name ="user_query" placeholder="search all product"/>
			<input type ="submit" name ="search" value ="search"/>
		</form>

	</div>
	<div class="content_wrapper">
		<div id="sidebar">
			<div id="sidebar_title">MENU</div>
			<ul id= "cats">
				<li><a href="#">BREAKFAST</a></li>
				<li><a href="#">LUNCH</a></li>
				<li><a href="#">BEVRAGES</a></li>
				<li><a href="#">SNACKS</a></li>
			</ul>
		</div>
		<div id="content_area"></div>
	</div>
	<div id="footer">
	</div>

		
		


