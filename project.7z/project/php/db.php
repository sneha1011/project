<?php
//Step1
 $db = mysqli_connect('localhost','root','','cart')  or die('Error connecting to MySQL server.');
?>
