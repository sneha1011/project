<?php
//Step1
 $db = mysqli_connect('localhost','root','','canteensystem')  or die('Error connecting to MySQL server.');
?>


<?php
//Step2
//echo $_POST['userid_name'];
$x=$_POST['userid_name'];
$y="";
$valid = true;
//$result = mysqli_query($db, $query)
//$row = mysqli_fetch_array($result);

if (empty($_POST["password_name"])) {
      $firstNameErr = "Password is required\n";
      $valid = false; //false
	  echo "this is".$firstNameErr;
}else if(empty($_POST["userid_name"])) {
      $firstNameErr = "Username is required";
      $valid = false; //false
	  echo $firstNameErr;
	 
}
else{
if(isset($_POST['password_name']))
{
	$y=$_POST['password_name'];
	echo 'TESTING'.$y;
}

//$query = "SELECT * FROM tab_account_master where cust_id = $x and cust_password ='$y' and cust_type='A'";

$query = "SELECT * FROM tab_account_master where cust_id = $x and cust_password ='$y'";
echo $query;
$result = mysqli_query($db, $query) or die('Incoreect Id or Password');
print_r($result);
while($row=mysqli_fetch_array($result))
{
	print_r($row);
	if($row['cust_id']==$x && $row['cust_password']==$y && $row['cust_type']=='A')
	{
		echo "mTCH FOUND for admin";
		header('location:admin.php');
	}
	else
	{
		echo "User screen";
		header('location:user.php');
	}
		
	
}

}
?>