<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<body background="food.jpg">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
     >
    </div>
    <ul class="nav navbar-nav">
     
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="breakfast.html">Breakfast</a></li>
          <li><a href="bevrages.html">Bavrages</a></li>
          <li><a href="lunch.html">Lunch</a></li>
          <li><a href="snacks.html">Snacks</a></li>
        </ul>
      </li>
      <li><a href="#">About</a></li>
      <li><a href="#">Account</a></li>
 <li><a href="#">Review</a></li>
 <li><a href="#">Contact</a></li>
    </ul>
  </div>
</nav>
  

<body>
<div class="container-fluid">

<div class="row">

<div class="col-md-4" >
<img class="img-responsive img-thumbnail" align="middle" src="coffee.jpg"style="padding-bottom: 10px;" height="420" width="420">
<div>Coffee</div>
</div>


<div class="col-md-4" >
<img class="img-responsive img-thumbnail" align="middle" src="tea.jpg"style="padding-bottom: 10px;" height="520" width="520">
<div>Tea</div>
</div>


<div class="col-md-4" >
<img class="img-responsive img-thumbnail" align="middle" src="lime water.jpg"style="padding-bottom: 10px;" height="420" width="420">  </div>
<div>lime water</div>
</div>



<div class="row">

<div class="col-md-4" >
<img class="img-responsive img-thumbnail" align="middle" src="butter milk.jpg"style="padding-bottom: 10px;" height="420" width="420">
<div>Butter milk</div>
</div>

<div class="col-md-4">
<img class="img-responsive img-thumbnail" align="middle" src="lassi.jpg"style="padding-bottom: 10px;"height="420" width="420">
<div>Lassi</div>
</div>

<div class="col-md-4" >
<img class="img-responsive img-thumbnail" align="middle" src="hot milk.jpg"style="padding-bottom: 10px;"height="420" width="420">
<div>hot milk</div>
</div>
</div>

<div class="row">

<div class="col-md-4" >
<img class="img-responsive img-thumbnail" align="middle" src="cold drink.jpg"style="padding-bottom: 10px;"height="1220" width="1220">
<div>Cold drink</div>
</div>

</div>

</div>
</body>

</html>



