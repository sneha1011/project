<html>
<body bgcolor="yellow">
<p style="text-align:center;">
<h1>
    K.J. Somaiya Institute of Engineering and Information Technology,Sion-Mumbai-400022</h1>

<br>
<p style="text-align:center;"><img src="logo.jpeg" alt="Logo" width="120" height="120"></p>
<h2  style="text-align:center;">CANTEEN ORDER SYSTEM</h2>
<form action="canteensystem.php" method="POST">
<p align="center">
User ID:<input type="text" style="text-align:center;" name="userid_name" ><br><br><br>
Password:<input type="text" name="password_name"><br><br><br>
<button type="submit" class="btn" name="login_user">login</button>

</p>

</form>
</body>
</html>
